from flask import Flask, render_template, request, session
import sqlite3, csv

app = Flask(__name__)

conn = sqlite3.connect('../ZachSiteDB.db')
conn.execute('''CREATE TABLE if not exists projects (projid INTEGER PRIMARY KEY, projname TEXT NOT NULL, desc TEXT NOT NULL, link TEXT NOT NULL, img TEXT);''')

with open('app/static/csv/projects.csv') as csvfile:
    curs = conn.cursor()
    reader = csv.reader(csvfile, delimiter=',', quotechar='"')
    for csvrow in reader:
        curs.execute('SELECT * FROM projects WHERE projname = ? LIMIT 1', (csvrow[0],))
        trow = curs.fetchone()
        if trow is None:
            t = (csvrow[0], csvrow[1], csvrow[2], csvrow[3])
            curs.execute('INSERT INTO projects (projname, desc, link, img) VALUES (?,?,?,?)', t)
        elif (csvrow[0] != trow[1] or csvrow[1] != trow[2] or csvrow[2] != trow[3] or csvrow[3] != trow[4]):
            t = (csvrow[0], csvrow[1], csvrow[2], csvrow[3], trow[0])
            curs.execute('UPDATE projects SET projname=?, desc=?, link=?, img=? WHERE projid=?', t)

conn.commit()
conn.close()

@app.route('/')
def home():
    if 'curPage' in session:
        if session['curPage'] == 'home':
            return render_template('homeText.html')
        else:
            return pageHandler(session['curPage'])
    else:
        session['curPage'] = "home"
        return render_template('homeText.html')

@app.route('/projects')
def projects():
   con = sqlite3.connect("../ZachSiteDB.db")
   con.row_factory = sqlite3.Row

   cur = con.cursor()
   cur.execute("SELECT * FROM projects")

   rows = cur.fetchall();
   return render_template("projects.html",rows = rows)

@app.route('/background_process', methods=['POST'])
def background_process():
    testString = request.form['searchText']
    print(testString)
    if (testString == 'projects'):
        session['curPage'] = "projects"
        return projects()
    elif (testString == 'home'):
        session['curPage'] = "home"
        return home()
    else:
        return 'nothing'

def pageHandler(curPage):
    if curPage == "projects":
        return projects()
    else:
        return 'nothing'

if __name__ == '__main__':
    app.secret_key = 'oihg49whg7hw4gi'
    app.run(debug=True)
